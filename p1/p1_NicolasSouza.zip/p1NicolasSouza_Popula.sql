-- ----------  AVALIACAO P1  ----------
--
--                    SCRIPT DE POPULAÇÃO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Nicolas Chagas Souza
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: NicolasSouza
--
-- Ultimas Alteracoes
--  
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--        
--
-- ---------------------------------------------------------

insert into ELEITOR (tituloEleitor, nome, dtNascimento) values
		(157895123, 'João Victor Macedo Rocha'	, '1990-09-18'), 
		(148498286, 'Jéssica Álida Valença Padilha'	, '1991-10-19'), 
		(182457896, 'Gisele Rocha Couto'		, '2001-02-10'); 


insert into VOTO (tituloEleitor, dtEleicao, tipo) values 
		(157895123, '2014-11-01', 'J'),
        (148498286, '2014-11-01', 'R'),
        (182457896, '2014-11-01', 'J'),
        (148498286, '2018-11-01', 'R');
      

insert into CANDIDATO (numero, tituloEleitor, dtEleicao) values
		(13, 365412789, '2018-11-01'),
        (13, 365412789, '2014-11-01'),
        (18, 258159357, '2014-11-01'),
        (19, 478632127, '2018-11-01'),
        (36, 798123456, '2018-11-01');

insert into JUSTIFICADO (id, descricao) values 
		(1, 'Estava viajando no período e não pude votar.'),
        (3, 'No dia da eleição eu estava doente e não votei.');

insert into REALIZADO (id, numeroCandidato) values
		(2, 13),
        (4, 36);

 