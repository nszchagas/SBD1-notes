-- ----------  AVALIACAO P1  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 09/08/2022
-- Autor(es) ..............: Nicolas Chagas Souza
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: NicolasSouza
--
-- Ultimas Alteracoes
--  
--
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--        
--
-- ---------------------------------------------------------


create database if not exists NicolasSouza;

use NicolasSouza;

create table ELEITOR (
	tituloEleitor		integer			not null,
    nome 				varchar(50)		not null,
    dtNascimento		date			not null,

	constraint eleitor_pk primary key(tituloEleitor)
);



create table VOTO (
	id 					integer 		auto_increment,
    tituloEleitor		integer			not null,
    dtEleicao			date			not null, 
    tipo				enum('J', 'R') 	not null,
    
    constraint eleitor_voto_fk foreign key (tituloEleitor) references ELEITOR(tituloEleitor),
    constraint voto_uk unique key (dtEleicao, tituloEleitor),
    constraint voto_pk primary key(id) 
) engine = InnoDB auto_increment = 1;


create table CANDIDATO(
	numero				integer 	not null,
    tituloEleitor		integer 	not null,
    dtEleicao			date		not null,
    
    constraint candidato_pk primary key(numero, dtEleicao),
    constraint tituloEleitor_uk unique key(tituloEleitor, dtEleicao)
);

create table JUSTIFICADO (
	id 					integer 		not null,
    descricao			varchar(500)	not null,
   
    constraint voto_justificado_fk foreign key(id) references VOTO(id)
);


create table REALIZADO (
	id 						integer 		not null,
    numeroCandidato			integer			not null,
    
    constraint realizado_uk unique key (id),
    constraint voto_realizado_fk foreign key(id) references VOTO(id),
    constraint realizado_candidato_fk foreign key(numeroCandidato) references CANDIDATO(numero)
);


	